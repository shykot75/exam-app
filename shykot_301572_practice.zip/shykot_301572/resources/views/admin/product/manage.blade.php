@extends('master.admin.master')

@section('body')
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manage Products</h1>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Manage Product Form</div>
                <div class="card-body">
                    <div class="table-responsive">
                        <p class="text-center text-success">{{Session::get('message')}}</p>
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>ID</th>
                                <th>Product Name</th>
                                <th>Category</th>
                                <th>Brand</th>
                                <th>description</th>
                                <th>Status</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($products as $product)
                                <tr>
                                    <td>{{$loop->iteration}}</td>
                                    <td>{{$product->id}}</td>
                                    <td>{{$product->name}}</td>
                                    <td>{{$product->category_name}}</td>
                                    <td>{{$product->brand_name}}</td>
                                    <td>{{$product->description}}</td>
                                    <td class="{{$product->status == 1 ? 'btn-sm btn-success' : 'btn-sm btn-danger'}}">{{$product->status == 1 ? 'Active' : 'Inactive'}} </td>
                                    <td><img src="{{asset($product->image)}}" alt="" height="50" width="50" class="img-fluid"></td>
                                    <td>
{{--                                        <a href="{{route('category.edit', ['id' => $product->id])}}" class="btn btn-success btn-sm">--}}
{{--                                            <i class="fa fa-edit"></i>--}}
{{--                                        </a>--}}
                                        <a href="{{route('product.edit', ['id' => $product->id])}}" class="btn btn-success btn-sm">
                                            <i class="fa fa-edit"></i>
                                        </a>
{{--                                        <a href="{{route('category.delete', ['id' => $product->id])}}" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure to delete this..')">--}}
{{--                                            <i class="fa fa-trash"></i>--}}
{{--                                        </a>--}}
                                        <a href="{{route('product.delete', ['id' => $product->id])}}" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure to delete this..')">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

@endsection

