<?php

namespace App\Http\Controllers;
use App\Http\Controllers\ProductController;

use App\Models\Product;
use Illuminate\Http\Request;

class ExamAppController extends Controller
{
    private $products;
    private $product;

    public function index(){
        $this->products = Product::where('status', 1)->orderBy('id', 'desc')->get();
        return view('website.home.home', ['products' => $this->products]);
    }

    public function details($id){
        $this->product = Product::find($id);
        return view('website.details.details', ['product' => $this->product]);
    }


}
