<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AdminDashboardController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\ExamAppController;
use App\Http\Controllers\AdminController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [ExamAppController::class, 'index'])->name('home');
Route::get('/product-details/{id}', [ExamAppController::class, 'details'])->name('details.product');

Route::middleware(['auth:sanctum', config('jetstream.auth_session'), 'verified'])->group(function () {

    Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');

    //PRODUCT
    Route::get('/add-product', [ProductController::class, 'index'])->name('product.add');
    Route::post('/new-product', [ProductController::class, 'create'])->name('product.new');
    Route::get('/manage-product', [ProductController::class, 'manage'])->name('product.manage');
    Route::get('/edit-product/{id}', [ProductController::class, 'edit'])->name('product.edit');
    Route::post('/update-product/{id}', [ProductController::class, 'update'])->name('product.update');
    Route::get('/delete-product/{id}', [ProductController::class, 'delete'])->name('product.delete');

    //ADMIN
    Route::get('/add-user', [AdminController::class, 'index'])->name('user.add');
    Route::post('/new-user', [AdminController::class, 'create'])->name('user.new');
    Route::get('/manage-user', [AdminController::class, 'manage'])->name('user.manage');
    Route::get('/edit-user/{id}', [AdminController::class, 'edit'])->name('user.edit');
    Route::post('/update-user/{id}', [AdminController::class, 'update'])->name('user.update');
    Route::get('/delete-user/{id}', [AdminController::class, 'delete'])->name('user.delete');


});
