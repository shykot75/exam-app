<?php $__env->startSection('title'); ?>
    Edit Product Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <section class="py-2">
        <div class="row">
            <div class="col-md-10 mx-auto">
                <div class="card">
                    <div class="card-header">Edit Product Form</div>
                    <div class="card-body">
                        <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                        <form action="<?php echo e(route('product.update', ['id' => $product->id])); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Product Name</label>
                                <div class="col-md-9">
                                    <input type="text" name="name" class="form-control" value="<?php echo e($product->name); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Category Name</label>
                                <div class="col-md-9">
                                    <input type="text" name="category_name" class="form-control" value="<?php echo e($product->category_name); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Brand Name</label>
                                <div class="col-md-9">
                                    <input type="text" name="brand_name" class="form-control" value="<?php echo e($product->brand_name); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Product Description</label>
                                <div class="col-md-9">
                                    <textarea name="description" class="form-control"><?php echo e($product->description); ?></textarea>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Product Image</label>
                                <div class="col-md-9">
                                    <img src="<?php echo e(asset($product->image)); ?>" alt="" height="150" width="150">
                                    <input type="file" name="image" class="form-control-file" accept="image/*">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Product Status</label>
                                <div class="col-md-9">
                                    <label><input type="radio" <?php echo e($product->status == 1 ? 'checked' : ''); ?> name="status" value="1"/> Active</label>
                                    <label><input type="radio" <?php echo e($product->status == 0 ? 'checked' : ''); ?> name="status" value="0"/> Inactive</label>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label"></label>
                                <div class="col-md-9">
                                    <input type="submit"  class="btn btn-outline-primary" value="Update Product">
                                </div>
                            </div>




                        </form>
                    </div>
                </div>

            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\laravel\bitm\shykot_301572\resources\views/admin/product/edit.blade.php ENDPATH**/ ?>