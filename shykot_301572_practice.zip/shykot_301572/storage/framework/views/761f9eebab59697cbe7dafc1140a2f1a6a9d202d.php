<?php $__env->startSection('title'); ?>
    ADD Product Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <section class="py-2">
        <div class="row">
            <div class="col-md-10 mx-auto">
                <div class="card">
                    <div class="card-header">ADD Product Form</div>
                    <div class="card-body">
                        <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                        <form action="<?php echo e(route('product.new')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Product Name</label>
                                <div class="col-md-9">
                                    <input type="text" name="name" class="form-control">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Category Name</label>
                                <div class="col-md-9">
                                    <input type="text" name="category_name" class="form-control">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Brand Name</label>
                                <div class="col-md-9">
                                    <input type="text" name="brand_name" class="form-control">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Product Description</label>
                                <div class="col-md-9">
                                    <textarea name="description" class="form-control"></textarea>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Product Image</label>
                                <div class="col-md-9">
                                    <input type="file" name="image" class="form-control-file" accept="image/*">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label"></label>
                                <div class="col-md-9">
                                    <input type="submit"  class="btn btn-outline-primary" value="ADD Product">
                                </div>
                            </div>




                        </form>
                    </div>
                </div>

            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shykot_batch_3_php\shykot_301572\resources\views/admin/product/add.blade.php ENDPATH**/ ?>