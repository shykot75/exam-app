<?php $__env->startSection('body'); ?>
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manage Products</h1>
    </div>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Manage Product Form</div>
                <div class="card-body">
                    <div class="table-responsive">
                        <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>ID</th>
                                <th>Product Name</th>
                                <th>Category</th>
                                <th>Brand</th>
                                <th>description</th>
                                <th>Status</th>
                                <th>Image</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($product->id); ?></td>
                                    <td><?php echo e($product->name); ?></td>
                                    <td><?php echo e($product->category_name); ?></td>
                                    <td><?php echo e($product->brand_name); ?></td>
                                    <td><?php echo e($product->description); ?></td>
                                    <td class="<?php echo e($product->status == 1 ? 'btn-sm btn-success' : 'btn-sm btn-danger'); ?>"><?php echo e($product->status == 1 ? 'Active' : 'Inactive'); ?> </td>
                                    <td><img src="<?php echo e(asset($product->image)); ?>" alt="" height="50" width="50" class="img-fluid"></td>
                                    <td>



                                        <a href="<?php echo e(route('product.edit', ['id' => $product->id])); ?>" class="btn btn-success btn-sm">
                                            <i class="fa fa-edit"></i>
                                        </a>



                                        <a href="<?php echo e(route('product.delete', ['id' => $product->id])); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure to delete this..')">
                                            <i class="fa fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shykot_batch_3_php\shykot_301572\resources\views/admin/product/manage.blade.php ENDPATH**/ ?>