<?php $__env->startSection('title'); ?>
    Edit Admin Page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <section class="py-2">
        <div class="row">
            <div class="col-md-10 mx-auto">
                <div class="card">
                    <div class="card-header">Edit Admin Form</div>
                    <div class="card-body">
                        <p class="text-center text-success"><?php echo e(Session::get('message')); ?></p>
                        <form action="<?php echo e(route('user.update', ['id' => $user->id])); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Admin Full Name</label>
                                <div class="col-md-9">
                                    <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Admin Email</label>
                                <div class="col-md-9">
                                    <input type="email" name="email" class="form-control" value="<?php echo e($user->email); ?>">
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label">Give New Password</label>
                                <div class="col-md-9">
                                    <input type="password" name="password" class="form-control">
                                </div>
                            </div>


                            <div class="form-group row">
                                <label for="" class="col-md-3 col-form-label"></label>
                                <div class="col-md-9">
                                    <input type="submit"  class="btn btn-outline-primary" value="Update New Admin">
                                </div>
                            </div>




                        </form>
                    </div>
                </div>

            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('master.admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\laravel\bitm\shykot_301572\resources\views/admin/user/edit.blade.php ENDPATH**/ ?>